<?php
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\bootstrap\Alert;
use yii\bootstrap\Button;
use yii\bootstrap\ButtonDropdown;
use yii\bootstrap\ButtonGroup;
use yii\bootstrap\Carousel;
use yii\bootstrap\Collapse;
use yii\bootstrap\Dropdown;
use yii\bootstrap\Modal;
use yii\bootstrap\Progress;
use yii\bootstrap\Tabs;

?>
<?php
    NavBar::begin([
        'brandLabel' => 'My Company',
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Home', 'url' => ['/site/index']],
            ['label' => 'About', 'url' => ['/site/about']],
            ['label' => 'Contact', 'url' => ['/site/contact']],
            Yii::$app->user->isGuest ?
                ['label' => 'Login', 'url' => ['/site/login']] :
                ['label' => 'Logout (' . Yii::$app->user->identity->username . ')',
                    'url' => ['/site/logout'],
                    'linkOptions' => ['data-method' => 'post']],
        ],
    ]);
    NavBar::end();
    
    echo Tabs::widget([
        'items' => [
            [
                'label' => 'One',
                'content' => 'Anim pariatur cliche...',
                'active' => true
            ],
            [
                'label' => 'Two',
                'content' => 'Anim pariatur cliche...',
                'headerOptions' => ['123'],
                'options' => ['id' => 'myveryownID'],
            ],
            [
                'label' => 'Example',
                'url' => 'http://www.example.com',
            ],
            [
                'label' => 'Dropdown',
                'items' => [
                    [
                        'label' => 'DropdownA',
                        'content' => 'DropdownA, Anim pariatur cliche...',
                    ],
                    [
                        'label' => 'DropdownB',
                        'content' => 'DropdownB, Anim pariatur cliche...',
                    ],
                ],
            ],
        ],
    ]);
    
    echo Alert::widget([
        'options' => [
            'class' => 'alert-warning',
            ],
        'body' => 'Say hello...',
    ]);
    
    echo Button::widget([
        'label' => 'Action',
        'options' => ['class' => 'btn-lg'],
    ]);
    
    echo ButtonDropdown::widget([
        'label' => 'Action',
        'dropdown' => [
                'items' => [
                        ['label' => 'DropdownA', 'url' => '/'],
                        ['label' => 'DropdownB', 'url' => '#'],
                    ],
            ],
    ]);
    
    echo ButtonGroup::widget([
        'buttons' => [
                ['label' => 'A'],
                ['label' => 'B'],
                ['label' => 'C', 'visible' => false],
            ]
    ]);
    
    echo Carousel::widget([
        'items' => [
                // the item contains only the image
                '<img src="../../assets/123.jpg"/>',
                // equivalent to the above
                ['content' => '<img src="../../assets/123.jpg"/>'],
                // the item contains both the image and the caption
                [
                        'content' => '<img src="../../assets/123.jpg"/>',
                        'caption' => '<h4>This is title</h4><p>This is the caption text</p>',
                        'options' => ['123'],
                    ],
            ]
    ]);
    
    echo Collapse::widget([
        'items' => [
                // equivalent to the above
                [
                        'label' => 'Collapsible Group Item #1',
                        'content' => 'Anim pariatur cliche...',
                        // open its content by default
                        'contentOptions' => ['class' => 'in']
                    ],
                // another group item
                [
                        'label' => 'Collapsible Group Item #1',
                        'content' => 'Anim pariatur cliche...',
                        'contentOptions' => ['123'],
                        'options' => ['123'],
                    ],
                // if you want to swap out .panel-body with .list-group, you may use the following
                [
                        'label' => 'Collapsible Group Item #1',
                        'content' => [
                                'Anim pariatur cliche...',
                                'Anim pariatur cliche...'
                            ],
                        'contentOptions' => ['1'],
                        'options' => ['2'],
                        'footer' => 'Footer' // the footer label in list-group
                    ],
            ]
    ]);
    
    Modal::begin([
    'header' => '<h2>Hello world</h2>',
    'toggleButton' => ['label' => 'click me'],
    ]);
    
    echo 'Say hello...';
    
    Modal::end();
    
    
    echo Progress::widget([
        'bars' => [
                ['percent' => 10, 'options' => ['class' => 'progress-bar-danger']],
                ['percent' => 50, 'label' => 'test', 'options' => ['class' => 'progress-bar-success']],
                ['percent' => 35, 'options' => ['class' => 'progress-bar-warning']],
            ]
    ]);
    
?>
<div class="dropdown">
 <a href="#" data-toggle="dropdown" class="dropdown-toggle">Label <b class="caret"></b></a>
 <?php
     echo Dropdown::widget([
         'items' => [
             ['label' => 'DropdownA', 'url' => '/'],
             ['label' => 'DropdownB', 'url' => '#'],
         ],
     ]);
 ?>
</div>