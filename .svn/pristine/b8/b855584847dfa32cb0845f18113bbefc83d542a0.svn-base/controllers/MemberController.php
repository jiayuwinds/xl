<?php

namespace app\controllers;

use Yii;
use yii\rest\ActiveController;

class MemberController extends ActiveController
{
    public $modelClass = 'app\models\Member';
}
